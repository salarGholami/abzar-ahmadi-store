"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ArrowLeft, ArrowUpLeft, BookOpen, Clock3, Search, SlidersHorizontal, Sparkles } from "lucide-react";
import type { StoreArticle } from "@/lib/types";

const PAGE_SIZE = 9;
const categoryOf = (article: StoreArticle) => article.category?.trim() || "راهنمای خرید";
const dateOf = (article: StoreArticle) => article.publishedAt || article.createdAt;

export default function MagazineBrowser({ articles }: { articles: StoreArticle[] }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("همه مطالب");
  const [sort, setSort] = useState("newest");
  const [page, setPage] = useState(1);

  const categories = useMemo(
    () => ["همه مطالب", ...Array.from(new Set(articles.map(categoryOf))).sort((a, b) => a.localeCompare(b, "fa"))],
    [articles],
  );
  const filtered = useMemo(() => {
    const term = query.trim().toLocaleLowerCase("fa");
    return articles
      .filter((article) => category === "همه مطالب" || categoryOf(article) === category)
      .filter((article) => !term || [article.title, article.excerpt, categoryOf(article)].some((value) => value?.toLocaleLowerCase("fa").includes(term)))
      .sort((a, b) => sort === "oldest"
        ? new Date(dateOf(a)).getTime() - new Date(dateOf(b)).getTime()
        : new Date(dateOf(b)).getTime() - new Date(dateOf(a)).getTime());
  }, [articles, category, query, sort]);

  const featured = filtered[0];
  const remaining = filtered.slice(1);
  const pageCount = Math.max(1, Math.ceil(remaining.length / PAGE_SIZE));
  const visible = remaining.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const resetPage = () => setPage(1);
  const formatDate = (value?: string) => {
    if (!value) return "مجله ابزار احمدی";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "مجله ابزار احمدی" : new Intl.DateTimeFormat("fa-IR", { year: "numeric", month: "long", day: "numeric" }).format(date);
  };

  return (
    <main dir="rtl" className="min-h-screen pb-16">
      <section className="relative isolate overflow-hidden border-b border-[var(--border)] bg-[var(--surface)]">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 opacity-70">
          <div className="absolute -left-20 -top-28 size-96 rounded-full bg-[var(--primary)]/10 blur-3xl" />
          <div className="absolute right-1/3 top-24 size-64 rounded-full bg-cyan-500/10 blur-3xl" />
          <div className="absolute inset-0 bg-[linear-gradient(to_right,var(--border)_1px,transparent_1px),linear-gradient(to_bottom,var(--border)_1px,transparent_1px)] bg-[size:48px_48px] opacity-20" />
        </div>
        <div className="mx-auto grid w-full max-w-[1500px] gap-10 px-4 py-14 sm:px-6 md:py-20 lg:grid-cols-[1.05fr_.95fr] lg:items-center lg:px-8">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-[var(--primary)]/25 bg-[var(--primary)]/10 px-3 py-2 text-xs font-extrabold text-[var(--primary)]">
              <Sparkles size={15} /> دانش فنی، انتخاب دقیق‌تر
            </div>
            <h1 className="mt-6 max-w-3xl text-4xl font-black leading-[1.45] tracking-tight sm:text-5xl lg:text-6xl">
              مجله ابزار احمدی
              <span className="mt-2 block text-[var(--primary)]">برای حرفه‌ای‌تر کار کردن.</span>
            </h1>
            <p className="mt-5 max-w-2xl text-sm leading-8 text-[var(--muted)] sm:text-base sm:leading-9">
              راهنمای خرید، بررسی مشخصات فنی، آموزش نگهداری و تجربه‌های کاربردی برای انتخاب ابزار درست؛ از کارگاه خانگی تا پروژه‌های حرفه‌ای.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3 text-xs font-bold text-[var(--muted)]">
              <span className="inline-flex items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--bg)] px-3 py-2"><BookOpen size={15} className="text-[var(--primary)]" /> {articles.length.toLocaleString("fa-IR")} مقاله منتشرشده</span>
              <span className="inline-flex items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--bg)] px-3 py-2"><Clock3 size={15} className="text-[var(--primary)]" /> محتوای کاربردی و تخصصی</span>
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-xl">
            <div className="absolute -inset-3 rounded-[2rem] border border-[var(--primary)]/20 rotate-2" />
            <div className="relative overflow-hidden rounded-[1.7rem] border border-[var(--border)] bg-[var(--surface-2)] p-2 shadow-2xl">
              <div className="grid grid-cols-2 gap-2">
                <div className="relative row-span-2 min-h-[260px] overflow-hidden rounded-2xl bg-[var(--bg-secondary)]">
                  <img src={featured?.image || "/placeholder-product.svg"} alt={featured?.imageAlt || featured?.title || "ابزارهای حرفه‌ای کارگاهی"} className="absolute inset-0 size-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
                  <div className="absolute bottom-0 p-4 text-white">
                    <span className="text-[10px] font-extrabold text-cyan-300">انتخاب سردبیر</span>
                    <p className="mt-2 line-clamp-3 text-sm font-black leading-6">{featured?.title || "دانش فنی برای انتخاب ابزار مناسب"}</p>
                  </div>
                </div>
                <div className="flex min-h-[125px] flex-col justify-between rounded-2xl border border-[var(--border)] bg-[var(--bg)] p-4">
                  <span className="grid size-10 place-items-center rounded-xl bg-[var(--primary)]/10 text-[var(--primary)]"><BookOpen size={20} /></span>
                  <div><p className="text-xs font-black">راهنمای خرید</p><p className="mt-1 text-[11px] leading-5 text-[var(--muted)]">انتخاب بر اساس نیاز واقعی</p></div>
                </div>
                <div className="flex min-h-[125px] flex-col justify-between rounded-2xl border border-[var(--border)] bg-[var(--bg)] p-4">
                  <span className="grid size-10 place-items-center rounded-xl bg-amber-500/10 text-amber-500"><SlidersHorizontal size={20} /></span>
                  <div><p className="text-xs font-black">بررسی فنی</p><p className="mt-1 text-[11px] leading-5 text-[var(--muted)]">مقایسه مشخصات و قابلیت‌ها</p></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto w-full max-w-[1500px] px-4 sm:px-6 lg:px-8">
        <section aria-label="جست‌وجو و دسته‌بندی مقالات" className="sticky top-2 z-20 mt-7 rounded-2xl border border-[var(--border)] bg-[var(--surface)]/95 p-3 shadow-lg backdrop-blur-xl sm:p-4">
          <div className="flex flex-col gap-3 xl:flex-row xl:items-center">
            <label className="relative min-w-0 flex-1">
              <Search size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
              <input value={query} onChange={(event) => { setQuery(event.target.value); resetPage(); }} placeholder="جست‌وجو در عنوان، خلاصه و دسته‌بندی..." className="h-12 w-full rounded-xl border border-[var(--border)] bg-[var(--bg)] pr-11 pl-4 text-sm outline-none transition focus:border-[var(--primary)]" aria-label="جست‌وجوی مقاله" />
            </label>
            <label className="flex h-12 items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--bg)] px-3 text-xs font-bold">
              <span className="text-[var(--muted)]">مرتب‌سازی</span>
              <select value={sort} onChange={(event) => { setSort(event.target.value); resetPage(); }} className="max-w-32 bg-transparent outline-none">
                <option value="newest">جدیدترین</option><option value="oldest">قدیمی‌ترین</option>
              </select>
            </label>
          </div>
          <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
            {categories.map((item) => <button key={item} type="button" onClick={() => { setCategory(item); resetPage(); }} className={`shrink-0 rounded-xl px-4 py-2.5 text-xs font-extrabold transition ${category === item ? "bg-[var(--primary)] text-[#10242a] shadow-md shadow-[var(--primary)]/20" : "border border-[var(--border)] bg-[var(--bg)] text-[var(--muted)] hover:border-[var(--primary)]/50 hover:text-[var(--text)]"}`}>{item}</button>)}
          </div>
        </section>

        <section className="mt-10">
          <div className="mb-5 flex items-end justify-between gap-3">
            <div><p className="text-xs font-extrabold text-[var(--primary)]">کتابخانه دانش ابزار</p><h2 className="mt-2 text-2xl font-black sm:text-3xl">مطالبی برای انتخاب بهتر</h2></div>
            <span className="text-xs text-[var(--muted)]">{filtered.length.toLocaleString("fa-IR")} نتیجه</span>
          </div>
          {filtered.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-[var(--border)] px-6 py-16 text-center"><Search size={30} className="mx-auto text-[var(--muted)]" /><h3 className="mt-4 font-black">مقاله‌ای پیدا نشد</h3><p className="mt-2 text-sm text-[var(--muted)]">عبارت جست‌وجو یا دسته‌بندی را تغییر دهید.</p><button onClick={() => { setQuery(""); setCategory("همه مطالب"); }} className="mt-5 rounded-xl bg-[var(--primary)] px-4 py-2.5 text-xs font-black text-[#10242a]">پاک کردن فیلترها</button></div>
          ) : (
            <>
              {featured && <Link href={`/magazine/${featured.slug}`} className="group mb-6 grid overflow-hidden rounded-[1.7rem] border border-[var(--border)] bg-[var(--surface)] transition hover:border-[var(--primary)]/40 lg:grid-cols-[1.05fr_.95fr]">
                <div className="relative min-h-[250px] overflow-hidden bg-[var(--surface-2)] sm:min-h-[330px]"><img src={featured.image || "/placeholder-product.svg"} alt={featured.imageAlt || featured.title} className="absolute inset-0 size-full object-cover transition duration-700 group-hover:scale-[1.03]" /><div className="absolute right-4 top-4 rounded-lg bg-black/65 px-3 py-1.5 text-[10px] font-black text-white backdrop-blur">مقاله منتخب</div></div>
                <div className="flex flex-col justify-center p-6 sm:p-9 lg:p-12"><div className="flex flex-wrap items-center gap-2 text-[11px] font-extrabold"><span className="rounded-lg bg-[var(--primary)]/10 px-3 py-1.5 text-[var(--primary)]">{categoryOf(featured)}</span><span className="text-[var(--muted)]">{formatDate(dateOf(featured))}</span></div><h3 className="mt-5 text-2xl font-black leading-[1.7] sm:text-3xl">{featured.title}</h3><p className="mt-4 line-clamp-3 text-sm leading-8 text-[var(--muted)]">{featured.excerpt}</p><span className="mt-7 inline-flex items-center gap-2 text-sm font-black text-[var(--primary)]">مطالعه مقاله <ArrowLeft size={17} className="transition-transform group-hover:-translate-x-1" /></span></div>
              </Link>}
              {visible.length > 0 && <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {visible.map((article) => <Link key={article.id} href={`/magazine/${article.slug}`} className="group flex min-w-0 flex-col overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--surface)] transition duration-300 hover:-translate-y-1 hover:border-[var(--primary)]/50 hover:shadow-xl">
                  <div className="relative aspect-[16/10] overflow-hidden bg-[var(--surface-2)]"><img src={article.image || "/placeholder-product.svg"} alt={article.imageAlt || article.title} loading="lazy" className="size-full object-cover transition duration-700 group-hover:scale-105" /><span className="absolute right-3 top-3 rounded-lg border border-white/20 bg-black/65 px-2.5 py-1.5 text-[10px] font-extrabold text-white backdrop-blur">{categoryOf(article)}</span></div>
                  <div className="flex flex-1 flex-col p-5"><div className="text-[11px] text-[var(--muted)]">{formatDate(dateOf(article))}{article.readingMinutes ? ` · ${article.readingMinutes} دقیقه مطالعه` : ""}</div><h3 className="mt-3 line-clamp-2 text-base font-black leading-7 transition group-hover:text-[var(--primary)]">{article.title}</h3><p className="mt-2 line-clamp-3 text-xs leading-7 text-[var(--muted)]">{article.excerpt}</p><div className="mt-auto flex items-center justify-between border-t border-[var(--border)] pt-4 mt-5 text-xs font-extrabold"><span className="text-[var(--primary)]">ادامه مطلب</span><span className="grid size-8 place-items-center rounded-full border border-[var(--border)] transition group-hover:border-[var(--primary)] group-hover:bg-[var(--primary)] group-hover:text-[#10242a]"><ArrowUpLeft size={15} /></span></div></div>
                </Link>)}
              </div>}
              {pageCount > 1 && <nav aria-label="صفحه‌بندی مقالات" className="mt-8 flex items-center justify-center gap-2"><button disabled={page === 1} onClick={() => setPage((value) => value - 1)} className="rounded-xl border border-[var(--border)] px-4 py-2.5 text-xs font-bold disabled:opacity-40">قبلی</button>{Array.from({ length: pageCount }, (_, index) => index + 1).map((number) => <button key={number} aria-current={page === number ? "page" : undefined} onClick={() => setPage(number)} className={`size-10 rounded-xl text-xs font-black ${page === number ? "bg-[var(--primary)] text-[#10242a]" : "border border-[var(--border)] bg-[var(--surface)]"}`}>{number.toLocaleString("fa-IR")}</button>)}<button disabled={page === pageCount} onClick={() => setPage((value) => value + 1)} className="rounded-xl border border-[var(--border)] px-4 py-2.5 text-xs font-bold disabled:opacity-40">بعدی</button></nav>}
            </>
          )}
        </section>
      </div>
    </main>
  );
}
