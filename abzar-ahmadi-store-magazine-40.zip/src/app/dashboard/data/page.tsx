"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Database,
  RefreshCw,
  Search,
  FileJson,
  Users,
  Boxes,
} from "lucide-react";
import Pagination from "@/shared/ui/Pagination";

type Row = Record<string, unknown> & { id?: string };
type DataResponse = {
  collections: Record<string, Row[] | null | undefined>;
  users: Row[] | null | undefined;
  generatedAt: string;
};

type IntegrityResponse = {
  healthy: boolean;
  summary: { errors: number; warnings: number };
};

const labels: Record<string, string> = {
  products: "محصولات",
  categories: "دسته‌بندی‌ها",
  brands: "برندها",
  customers: "مشتریان",
  suppliers: "تأمین‌کنندگان",
  sales: "فروش‌ها",
  "sale-items": "آیتم‌های فروش",
  purchases: "خریدها",
  "purchase-items": "آیتم‌های خرید",
  inventory: "موجودی و گردش انبار",
  finance: "دفتر مالی",
  expenses: "هزینه‌ها",
  incomes: "درآمدها",
  checks: "چک‌ها",
  quotations: "پیش‌فاکتورها",
  "quotation-items": "آیتم‌های پیش‌فاکتور",
  "activity-logs": "لاگ فعالیت‌ها",
  settings: "تنظیمات",
  users: "کاربران",
};

function asRows(value: unknown): Row[] {
  return Array.isArray(value) ? (value as Row[]) : [];
}

function display(value: unknown) {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

function DataTable({ rows }: { rows: Row[] }) {
  const list = asRows(rows);
  const keys = useMemo(
    () =>
      Array.from(new Set(list.flatMap((row) => Object.keys(row)))).slice(0, 9),
    [list],
  );

  if (!list.length) {
    return (
      <div className="p-8 text-center text-sm text-[var(--muted)]">
        داده‌ای ثبت نشده است.
      </div>
    );
  }

  return (
    <div className="overflow-auto">
      <table className="w-full min-w-[900px] text-right text-xs">
        <thead className="bg-[var(--surface-2)] text-[var(--muted)]">
          <tr>
            {keys.map((key) => (
              <th key={key} className="p-3 font-black">
                {key}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {list.slice(0, 100).map((row, index) => (
            <tr
              key={String(row.id ?? index)}
              className="border-t border-[var(--border)] align-top"
            >
              {keys.map((key) => (
                <td key={key} className="max-w-[260px] break-words p-3">
                  {display(row[key])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {list.length > 100 && (
        <div className="border-t border-[var(--border)] p-3 text-center text-[10px] text-[var(--muted)]">
          نمایش ۱۰۰ رکورد اول از {list.length.toLocaleString("fa-IR")} رکورد
        </div>
      )}
    </div>
  );
}

export default function DataCenterPage() {
  const [data, setData] = useState<DataResponse | null>(null);
  const [integrity, setIntegrity] = useState<IntegrityResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [active, setActive] = useState("products");
  const [activePage, setActivePage] = useState(1);

  async function load() {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/admin/data-center", {
        cache: "no-store",
      });
      const result = await response.json();
      if (!response.ok || !result.success) {
        throw new Error(result.error?.message || "دریافت داده‌ها انجام نشد.");
      }
      setData(result.data);
      const integrityResponse = await fetch("/api/admin/data-integrity", { cache: "no-store" });
      const integrityResult = await integrityResponse.json();
      if (integrityResponse.ok && integrityResult.success) setIntegrity(integrityResult.data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در ارتباط با سرور");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const entries = useMemo(() => {
    if (!data) return [] as [string, Row[]][];
    const collections = data.collections || {};
    const list: [string, Row[]][] = Object.entries(collections).map(
      ([key, value]) => [key, asRows(value)],
    );
    list.push(["users", asRows(data.users)]);
    return list;
  }, [data]);

  const filteredEntries = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return entries;
    return entries.filter(([key, rows]) => {
      if (`${labels[key] || ""} ${key}`.toLowerCase().includes(q)) return true;
      return rows.some((row) =>
        Object.values(row).some((value) =>
          display(value).toLowerCase().includes(q),
        ),
      );
    });
  }, [entries, query]);

  const activeRows = useMemo(() => {
    if (!data) return [] as Row[];
    if (active === "users") return asRows(data.users);
    return asRows(data.collections?.[active]);
  }, [data, active]);

  const activePagination = useMemo(() => {
    const total = activeRows.length;
    const pageSize = 20;
    return {
      page: Math.min(activePage, Math.max(1, Math.ceil(total / pageSize))),
      pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    };
  }, [activeRows, activePage]);

  const visibleRows = useMemo(() => {
    const start = (activePagination.page - 1) * activePagination.pageSize;
    return activeRows.slice(start, start + activePagination.pageSize);
  }, [activeRows, activePagination]);

  const totalRecords = useMemo(
    () => entries.reduce((sum, [, rows]) => sum + rows.length, 0),
    [entries],
  );

  return (
    <div className="mx-auto max-w-[1500px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-xs font-black text-[var(--primary)]">
            مدیریت مرکزی
          </div>
          <h1 className="mt-1 text-3xl font-black">مرکز تمام داده‌ها</h1>
          <p className="mt-2 text-sm text-[var(--muted)]">
            تمام داده‌های عملیاتی فروشگاه، بدون دسترسی مستقیم به فایل‌های JSON،
            از اینجا قابل مشاهده‌اند.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void load()}
          className="btn btn-secondary"
        >
          <RefreshCw size={17} />
          بروزرسانی
        </button>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-4">
        <div className={`card p-5 ${integrity?.healthy ? "" : "border-red-300 dark:border-red-800"}`}>
          <div className="text-xs font-bold text-[var(--muted)]">سلامت داده</div>
          <div className="mt-2 text-xl font-black">
            {integrity
              ? integrity.summary.errors > 0
                ? `${integrity.summary.errors.toLocaleString("fa-IR")} خطا`
                : integrity.summary.warnings > 0
                  ? "دارای هشدار"
                  : "سالم"
              : "در حال بررسی"}
          </div>
          {integrity && integrity.summary.warnings > 0 ? <div className="mt-1 text-[10px] text-amber-600">{integrity.summary.warnings.toLocaleString("fa-IR")} هشدار</div> : null}
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-2 text-xs font-bold text-[var(--muted)]">
            <Database size={15} /> مجموعه‌ها
          </div>
          <div className="mt-2 text-3xl font-black">
            {entries.length.toLocaleString("fa-IR")}
          </div>
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-2 text-xs font-bold text-[var(--muted)]">
            <Boxes size={15} /> کل رکوردها
          </div>
          <div className="mt-2 text-3xl font-black">
            {totalRecords.toLocaleString("fa-IR")}
          </div>
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-2 text-xs font-bold text-[var(--muted)]">
            <Users size={15} /> کاربران
          </div>
          <div className="mt-2 text-3xl font-black">
            {asRows(data?.users).length.toLocaleString("fa-IR")}
          </div>
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[280px_1fr]">
        <aside className="card h-fit p-3">
          <div className="relative">
            <Search
              className="absolute right-3 top-3 text-[var(--muted)]"
              size={16}
            />
            <input
              className="input pr-9"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="جستجوی داده..."
            />
          </div>
          <div className="mt-3 max-h-[65vh] space-y-1 overflow-auto">
            {filteredEntries.map(([key, rows]) => (
              <button
                type="button"
                key={key}
                onClick={() => { setActive(key); setActivePage(1); }}
                className={`flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-right text-xs font-bold ${
                  active === key
                    ? "bg-[var(--primary)] text-white"
                    : "hover:bg-[var(--surface-2)]"
                }`}
              >
                <span>{labels[key] || key}</span>
                <span className="opacity-70">
                  {rows.length.toLocaleString("fa-IR")}
                </span>
              </button>
            ))}
          </div>
        </aside>

        <section className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--border)] p-5">
            <div>
              <div className="flex items-center gap-2">
                <FileJson size={18} className="text-[var(--primary)]" />
                <h2 className="font-black">{labels[active] || active}</h2>
              </div>
              <p className="mt-1 text-xs text-[var(--muted)]">
                {activeRows.length.toLocaleString("fa-IR")} رکورد
              </p>
            </div>
          </div>

          {loading ? (
            <div className="p-12 text-center text-sm text-[var(--muted)]">
              در حال دریافت تمام داده‌ها...
            </div>
          ) : error ? (
            <div className="p-12 text-center text-sm text-red-600">{error}</div>
          ) : (
            <>
              <DataTable rows={visibleRows} />
              <Pagination pagination={activePagination} onPageChange={setActivePage} />
            </>
          )}
        </section>
      </div>
    </div>
  );
}
