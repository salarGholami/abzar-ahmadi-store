import { Suspense } from "react";
import Image from "next/image";
import RegisterForm from "@/features/auth/ui/RegisterForm";
import Link from "next/link";
import { HomeIcon } from "lucide-react";

export default function RegisterPage() {
  return (
    <>

      <main className="flex min-h-[calc(100dvh-120px)] items-center justify-center px-4 py-6 sm:py-8">
        <div className="grid w-full max-w-5xl grid-cols-1 items-center gap-6 md:grid-cols-2 md:gap-10">
          {/* ===== تصویر (فقط از md به بالا) ===== */}
          <div className="relative hidden h-[400px] w-full overflow-hidden rounded-2xl md:block lg:h-[600px]">
            <Image
              src="/images/auth/register/cover-register.webp"
              alt="ثبت‌نام در حساب کاربری"
              fill
              className="object-cover"
              priority
              sizes="(max-width: 768px) 100vw, 50vw"
            />

            {/* لایه مشکی */}
            <div className="absolute inset-0 bg-black/50" />

            {/* متن روی تصویر */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="flex flex-col items-center justify-center gap-4">
                <span className="text-4xl font-bold text-white">
                  ابزار احمدی
                </span>
                <Link
                  href="/"
                  className="flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-sm font-bold text-white backdrop-blur-sm transition hover:bg-white/20"
                >
                  <HomeIcon className="h-4 w-4" />
                  <span>بازگشت به صفحه اصلی</span>
                </Link>
              </div>
            </div>
          </div>

          {/* ===== فرم ===== */}
          <div className="mx-auto w-full max-w-md">
            <div className="card p-5 sm:p-7">
              <div className="text-xs font-bold text-[var(--primary)]">
                حساب کاربری
              </div>
              <h1 className="mt-2 text-base font-black sm:text-lg">
                حساب کاربریت رو بساز !
              </h1>

              <Suspense>
                <RegisterForm />
              </Suspense>

              <p className="mt-5 text-center text-sm text-[var(--muted)]">
                قبلاً حساب دارید؟{" "}
                <Link
                  href="/account"
                  className="font-bold text-[var(--primary)]"
                >
                  ورود
                </Link>
              </p>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
